<?php
    include_once'connection.php';

    $Username = $_POST['username'];
    $Gender = $_POST['gender'];
    $Dob = $_POST['dob'];
    $Posi = $_POST['position'];
    
    // else {
        $sql = "INSERT INTO employees (emp_name,gender,dob) VALUES ('$Username','$Gender','$Dob')";

        if ($con->query($sql) === TRUE){
            $message = "Data inserted.";
            
            echo "<script type='text/javascript'>alert('$message');</script>";
            echo "<script> location.href='register.php'</script>";
            // <div class='alert alert-success alert-dismissible fade in'>
            //     <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            //     <strong>Success!</strong> This alert box could indicate a successful or positive action.
            // </div>
        }else{
            $message = "Data not inserted.";
            echo "<script type='text/javascript'>alert('$message');</script>";
            echo "<script> location.href='register.php'</script>";
        }
    // }
?>