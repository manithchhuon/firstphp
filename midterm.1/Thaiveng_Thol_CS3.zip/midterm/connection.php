<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "employee";
    $con = mysqli_connect('localhost','root','');
    
    if(!$con)
    {
        echo " not connected";
    }
    if(!mysqli_select_db($con,'employee'))
    {
        echo "Database not select";
    }
    
?>